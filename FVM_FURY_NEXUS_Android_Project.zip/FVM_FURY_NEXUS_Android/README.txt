FVM FURY NEXUS Android wrapper project

The original HTML is bundled unchanged at:
app/src/main/assets/index.html

Build an APK:
1. Install Android Studio on a computer.
2. Open this folder as an existing Android Studio project.
3. Allow Gradle sync/downloads.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is normally created at app/build/outputs/apk/debug/app-debug.apk.

Notes:
- This project wraps the existing HTML in Android WebView and grants internet access for its live API.
- Some remote CDN assets/API calls may fail if the remote service blocks WebView/CORS or changes its API.
- Prediction output is not guaranteed to be accurate; this wrapper does not change the original prediction logic.
- This ZIP is Android Studio source, not a compiled APK. A compiled APK requires Android build tools/Gradle dependencies.
